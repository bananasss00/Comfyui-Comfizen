https://github.com/unosquare/ffmediaelement/issues/679
ffmpeg-n4.4.4-94-g5d07afd482-win64-gpl-shared-4.4


To repeat the instructions all in one place, use these versions.

  *   FFME.Windows NuGet package version 4.4.350
  *   FFMPEG.AutoGen NuGet package version 4.4.1.1
  *   FFMPEG build 4.4.4-94-win64-gpl-shared

4.4.4 64-bit builds can be found at https://github.com/BtbN/FFmpeg-Builds/releases/tag/autobuild-2024-03-31-17-28
If targetting 32-bit, you can use https://github.com/defisym/FFmpeg-Builds-Win32/releases/tag/autobuild-2024-03-31-12-42

If using the 64 bit build and Visual Studio, unclick the ‘Prefer 32 bit’ checkbox in the Properties/Buiild options